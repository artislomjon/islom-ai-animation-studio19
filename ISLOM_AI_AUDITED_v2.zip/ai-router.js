const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const PORT = Number(process.env.PORT) || 3000;
const REQUEST_TIMEOUT_MS = 30000;

const AI_PROVIDERS = [
  {
    name: "Gemini",
    url: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
    key: process.env.GEMINI_API_KEY,
    model: process.env.GEMINI_MODEL || "gemini-2.5-flash"
  },
  {
    name: "OpenRouter",
    url: "https://openrouter.ai/api/v1/chat/completions",
    key: process.env.OPENROUTER_API_KEY,
    model: process.env.OPENROUTER_MODEL || "openrouter/free"
  }
];

app.get("/", (_req, res) => {
  res.json({ project: "ISLOM AI HUB", status: "online", mode: "FREE" });
});

app.get("/health", (_req, res) => {
  res.json({
    status: "ok",
    configuredProviders: AI_PROVIDERS.filter(p => Boolean(p.key)).map(p => p.name)
  });
});

app.post("/ai", async (req, res) => {
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  if (!message) return res.status(400).json({ error: "Введите сообщение" });
  if (message.length > 20000) {
    return res.status(413).json({ error: "Сообщение слишком длинное (максимум 20000 символов)" });
  }

  const configured = AI_PROVIDERS.filter(provider => Boolean(provider.key));
  if (configured.length === 0) {
    return res.status(503).json({
      error: "Не настроены ключи AI-провайдеров. Добавьте GEMINI_API_KEY или OPENROUTER_API_KEY в Environment."
    });
  }

  const failures = [];
  for (const ai of configured) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      const response = await fetch(ai.url, {
        method: "POST",
        signal: controller.signal,
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${ai.key}`
        },
        body: JSON.stringify({
          model: ai.model,
          messages: [{ role: "user", content: message }]
        })
      });

      const responseText = await response.text();
      if (!response.ok) {
        console.error(`${ai.name} API error ${response.status}: ${responseText.slice(0, 1500)}`);
        failures.push({ provider: ai.name, status: response.status });
        continue;
      }

      let data;
      try {
        data = JSON.parse(responseText);
      } catch {
        console.error(`${ai.name} returned invalid JSON`);
        failures.push({ provider: ai.name, error: "invalid_json" });
        continue;
      }

      const result = data?.choices?.[0]?.message?.content;
      if (typeof result !== "string" || !result.trim()) {
        console.error(`${ai.name} returned no message content`);
        failures.push({ provider: ai.name, error: "empty_response" });
        continue;
      }

      return res.json({ provider: ai.name, result });
    } catch (error) {
      console.error(`${ai.name} fetch error:`, error.message);
      failures.push({
        provider: ai.name,
        error: error.name === "AbortError" ? "timeout" : "connection_error"
      });
    } finally {
      clearTimeout(timeout);
    }
  }

  return res.status(503).json({
    error: "Все настроенные бесплатные ИИ сейчас недоступны. Попробуйте позже.",
    providers: failures
  });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`ISLOM AI HUB запущен на порту ${PORT}`);
});
