const message = "Привет! Ответь: ISLOM AI работает.";

fetch("https://islom-ai-android-1.onrender.com/ai", {
  method: "POST",
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify({ message })
})
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error(error));
